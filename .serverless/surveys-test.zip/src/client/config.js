const API = "https://n70xgo22r2.execute-api.ap-northeast-2.amazonaws.com";

export const USER_POLL_API = `${API}/dev/survey`;
export const ADMIN_POLL_API = `${API}/dev/admin/survey`;
export const TOKEN = '';